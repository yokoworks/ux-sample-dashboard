Linden Bakery & Café — Example CSV files

Use these files with the Staff Schedule Demo for 15 October 2026.
Unzip this archive, then choose a CSV using Upload CSV in the demo.

success.csv — Saves successfully, without coverage warnings.
warnings.csv — Saves with warnings: one person at 09:00–10:00 and no one at 16:00–17:00.
all-off-duty.csv — Saves with one grouped warning: no one at 09:00–17:00.
corrections.csv — Shows four corrections: Anna's short shift, Clara's split shift, an invalid value on row 4, and Ben's missing row. Does not change the saved schedule.
wrong-date.csv — Intentionally uses 16 October 2026. Rejected because the selected day is 15 October. Does not change the saved schedule.
missing-column.csv — Rejected because a required time column is missing. Does not change the saved schedule.
truncated-row.csv — Rejected because a record is incomplete. Does not change the saved schedule.

Download CSV in the dashboard exports the currently saved schedule; it is separate from this example pack.
CSV files are processed in your browser. Refreshing the page resets this in-memory demo.

Source: https://github.com/yokoworks/ux-sample-dashboard
